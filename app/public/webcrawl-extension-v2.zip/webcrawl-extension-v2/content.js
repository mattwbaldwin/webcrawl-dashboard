// Webcrawl Content Script v2
// On-page beacon and cache card overlay

(function() {
  // Prevent multiple injections
  if (window.__webcrawlLoaded) return;
  window.__webcrawlLoaded = true;

  const AMBER = '#C17F24';
  const AMBER_LIGHT = '#FDF4E7';
  const GREEN = '#22c55e';
  
  // ============================================
  // STYLES
  // ============================================
  
  const style = document.createElement('style');
  style.textContent = `
    @keyframes webcrawl-glow-hot {
      0%, 100% { box-shadow: 0 0 20px ${AMBER}, 0 0 40px ${AMBER}88, 0 0 60px ${AMBER}44; }
      50% { box-shadow: 0 0 30px ${AMBER}, 0 0 50px ${AMBER}aa, 0 0 80px ${AMBER}66; }
    }
    
    @keyframes webcrawl-glow-warm {
      0%, 100% { box-shadow: 0 0 10px ${AMBER}66, 0 0 20px ${AMBER}33; }
      50% { box-shadow: 0 0 18px ${AMBER}88, 0 0 35px ${AMBER}55; }
    }
    
    @keyframes webcrawl-pulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.08); }
    }
    
    @keyframes webcrawl-fade-in {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    #webcrawl-beacon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 2147483647;
      width: 56px;
      height: 56px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      cursor: pointer;
      transition: all 0.4s ease;
      border: none;
      background: white;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
      font-family: system-ui, -apple-system, sans-serif;
    }
    
    #webcrawl-beacon.cold {
      background: #f5f5f5;
      color: #aaa;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    
    #webcrawl-beacon.warm {
      background: ${AMBER_LIGHT};
      color: ${AMBER};
      border: 2px solid ${AMBER}44;
      animation: webcrawl-glow-warm 2s ease-in-out infinite, webcrawl-pulse 2.5s ease-in-out infinite;
    }
    
    #webcrawl-beacon.hot {
      background: ${AMBER};
      color: white;
      border: 2px solid ${AMBER};
      animation: webcrawl-glow-hot 1.2s ease-in-out infinite, webcrawl-pulse 1s ease-in-out infinite;
    }
    
    #webcrawl-beacon.found {
      background: ${GREEN};
      color: white;
      border: 2px solid ${GREEN};
      box-shadow: 0 4px 20px rgba(34, 197, 94, 0.4);
    }
    
    #webcrawl-card {
      position: fixed;
      bottom: 90px;
      right: 20px;
      width: 320px;
      background: white;
      border-radius: 16px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.2);
      z-index: 2147483647;
      animation: webcrawl-fade-in 0.3s ease;
      overflow: hidden;
      font-family: system-ui, -apple-system, sans-serif;
    }
    
    .webcrawl-card-header {
      background: linear-gradient(135deg, ${AMBER}, #D4922E);
      color: white;
      padding: 20px;
      text-align: center;
      position: relative;
    }
    
    .webcrawl-card-header.found {
      background: linear-gradient(135deg, ${GREEN}, #16a34a);
    }
    
    .webcrawl-card-close {
      position: absolute;
      top: 10px;
      right: 10px;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      border: none;
      background: rgba(255,255,255,0.2);
      color: white;
      font-size: 18px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .webcrawl-card-icon {
      width: 48px;
      height: 48px;
      background: rgba(255,255,255,0.2);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 12px;
      font-size: 24px;
    }
    
    .webcrawl-card-label {
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 1px;
      opacity: 0.9;
    }
    
    .webcrawl-card-name {
      font-size: 20px;
      font-weight: 700;
      margin-top: 4px;
    }
    
    .webcrawl-card-body {
      padding: 20px;
    }
    
    .webcrawl-card-message {
      font-size: 14px;
      color: #444;
      line-height: 1.6;
      margin-bottom: 16px;
      white-space: pre-wrap;
    }
    
    .webcrawl-card-clue {
      font-size: 13px;
      color: #666;
      font-style: italic;
      margin-bottom: 16px;
      padding: 12px;
      background: ${AMBER_LIGHT};
      border-radius: 8px;
    }
    
    .webcrawl-card-hint {
      font-size: 12px;
      color: #888;
      margin-bottom: 16px;
    }
    
    .webcrawl-card-hint strong {
      color: ${AMBER};
    }
    
    .webcrawl-card-stats {
      display: flex;
      gap: 16px;
      margin-bottom: 16px;
      font-size: 13px;
      color: #666;
    }
    
    .webcrawl-card-stat {
      display: flex;
      align-items: center;
      gap: 4px;
    }
    
    .webcrawl-card-btn {
      width: 100%;
      padding: 14px;
      border: none;
      border-radius: 10px;
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      background: ${AMBER};
      color: white;
      font-family: inherit;
      transition: background 0.15s ease;
    }
    
    .webcrawl-card-btn:hover {
      background: #a86b1d;
    }
    
    .webcrawl-card-btn:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    
    .webcrawl-card-btn.success {
      background: ${GREEN};
    }
    
    .webcrawl-toast {
      position: fixed;
      bottom: 90px;
      right: 20px;
      padding: 14px 20px;
      border-radius: 12px;
      font-family: system-ui, sans-serif;
      font-size: 14px;
      z-index: 2147483647;
      animation: webcrawl-fade-in 0.3s ease;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    }
    
    .webcrawl-toast.warm {
      background: ${AMBER_LIGHT};
      border: 2px solid ${AMBER}66;
      color: #92550e;
    }
    
    .webcrawl-toast.cold {
      background: #f5f5f5;
      border: 1px solid #ddd;
      color: #666;
    }
    
    .webcrawl-toast.error {
      background: #fee2e2;
      border: 1px solid #fecaca;
      color: #dc2626;
    }
  `;
  document.head.appendChild(style);

  // ============================================
  // STATE
  // ============================================
  
  let currentStatus = 'cold';
  let currentCache = null;
  let alreadyFound = false;
  let cardVisible = false;

  // ============================================
  // BEACON
  // ============================================
  
  const beacon = document.createElement('button');
  beacon.id = 'webcrawl-beacon';
  beacon.className = 'cold';
  beacon.textContent = '◈';
  beacon.addEventListener('click', handleBeaconClick);
  document.body.appendChild(beacon);

  // ============================================
  // MESSAGE HANDLING
  // ============================================
  
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'URL_STATUS') {
      updateStatus(msg.status, msg.cache, msg.alreadyFound);
    }
  });

  // Initial check
  checkCurrentUrl();

  // Re-check on URL changes (SPAs)
  let lastUrl = window.location.href;
  const urlObserver = setInterval(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      checkCurrentUrl();
    }
  }, 500);

  // ============================================
  // FUNCTIONS
  // ============================================
  
  async function checkCurrentUrl() {
    try {
      const result = await chrome.runtime.sendMessage({ 
        type: 'CHECK_URL', 
        url: window.location.href 
      });
      updateStatus(result.status, result.cache, result.alreadyFound);
    } catch (e) {
      console.error('Webcrawl: Error checking URL', e);
    }
  }

  function updateStatus(status, cache, found) {
    currentStatus = status;
    currentCache = cache;
    alreadyFound = found;
    
    beacon.className = '';
    
    if (found) {
      beacon.classList.add('found');
      beacon.textContent = '✓';
    } else {
      beacon.classList.add(status);
      beacon.textContent = '◈';
    }
    
    // Auto-show card when hot and not found
    if (status === 'hot' && !found && !cardVisible) {
      showCacheCard();
    }
    
    // Hide card if navigated away
    if (status !== 'hot' && !found && cardVisible) {
      hideCard();
    }
  }

  function handleBeaconClick() {
    if (cardVisible) {
      hideCard();
    } else if (currentStatus === 'hot' || alreadyFound) {
      showCacheCard();
    } else if (currentStatus === 'warm') {
      showToast('🔥 Cache nearby! Keep exploring this site...', 'warm');
    } else {
      showToast('No caches nearby. Keep exploring!', 'cold');
    }
  }

  function showCacheCard() {
    if (!currentCache) return;
    
    hideCard();
    
    const card = document.createElement('div');
    card.id = 'webcrawl-card';
    
    if (alreadyFound) {
      // Already found view
      card.innerHTML = `
        <div class="webcrawl-card-header found">
          <button class="webcrawl-card-close">×</button>
          <div class="webcrawl-card-icon">✓</div>
          <div class="webcrawl-card-label">Already Found</div>
          <div class="webcrawl-card-name">${esc(currentCache.name)}</div>
        </div>
        <div class="webcrawl-card-body">
          <div class="webcrawl-card-message">${esc(currentCache.message)}</div>
          <div class="webcrawl-card-stats">
            <div class="webcrawl-card-stat">👥 ${currentCache.finds_count} finds</div>
            ${currentCache.owner_display ? `<div class="webcrawl-card-stat">📍 by ${esc(currentCache.owner_display)}</div>` : ''}
          </div>
        </div>
      `;
    } else {
      // New find view
      card.innerHTML = `
        <div class="webcrawl-card-header">
          <button class="webcrawl-card-close">×</button>
          <div class="webcrawl-card-icon">◈</div>
          <div class="webcrawl-card-label">Cache Found!</div>
          <div class="webcrawl-card-name">${esc(currentCache.name)}</div>
        </div>
        <div class="webcrawl-card-body">
          <div class="webcrawl-card-clue">"${esc(currentCache.clue)}"</div>
          <div class="webcrawl-card-message">${esc(currentCache.message)}</div>
          ${currentCache.hint ? `<div class="webcrawl-card-hint"><strong>Hint:</strong> ${esc(currentCache.hint)}</div>` : ''}
          <div class="webcrawl-card-stats">
            <div class="webcrawl-card-stat">👥 ${currentCache.finds_count} finds</div>
            ${currentCache.owner_display ? `<div class="webcrawl-card-stat">📍 by ${esc(currentCache.owner_display)}</div>` : ''}
          </div>
          <button class="webcrawl-card-btn" id="webcrawl-log-btn">🎉 Log Find</button>
        </div>
      `;
    }
    
    document.body.appendChild(card);
    cardVisible = true;
    
    // Event listeners
    card.querySelector('.webcrawl-card-close').addEventListener('click', hideCard);
    
    const logBtn = document.getElementById('webcrawl-log-btn');
    if (logBtn) {
      logBtn.addEventListener('click', logFind);
    }
  }

  async function logFind() {
    const btn = document.getElementById('webcrawl-log-btn');
    if (!btn || !currentCache) return;
    
    btn.textContent = 'Logging...';
    btn.disabled = true;
    
    try {
      const result = await chrome.runtime.sendMessage({
        type: 'LOG_FIND',
        cacheId: currentCache.id
      });
      
      if (result.success) {
        alreadyFound = true;
        currentCache.finds_count = result.findNumber;
        
        // Update beacon
        beacon.className = 'found';
        beacon.textContent = '✓';
        
        // Update card
        const header = document.querySelector('.webcrawl-card-header');
        if (header) {
          header.classList.add('found');
          header.querySelector('.webcrawl-card-icon').textContent = '✓';
          header.querySelector('.webcrawl-card-label').textContent = result.isFtc ? '🏆 First to Crawl!' : 'Logged!';
        }
        
        btn.textContent = result.isFtc ? `🏆 FTC! You're #${result.findNumber}!` : `You're finder #${result.findNumber}!`;
        btn.classList.add('success');
        
      } else {
        btn.textContent = result.error || 'Error';
        setTimeout(() => {
          btn.textContent = '🎉 Log Find';
          btn.disabled = false;
        }, 2000);
      }
    } catch (error) {
      console.error('Error logging find:', error);
      btn.textContent = 'Error - try again';
      btn.disabled = false;
    }
  }

  function hideCard() {
    const card = document.getElementById('webcrawl-card');
    if (card) card.remove();
    cardVisible = false;
  }

  function showToast(message, type = 'cold') {
    // Remove existing toast
    const existing = document.querySelector('.webcrawl-toast');
    if (existing) existing.remove();
    
    const toast = document.createElement('div');
    toast.className = `webcrawl-toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => toast.remove(), 3000);
  }

  function esc(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // Cleanup on unload
  window.addEventListener('beforeunload', () => {
    clearInterval(urlObserver);
  });
})();
