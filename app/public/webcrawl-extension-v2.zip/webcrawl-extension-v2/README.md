# Webcrawl Extension v2

Browser extension with Supabase backend integration.

## Setup

### 1. Configure Supabase

Edit `background.js` and update the CONFIG object:

```javascript
const CONFIG = {
  SUPABASE_URL: 'https://YOUR_PROJECT.supabase.co',
  SUPABASE_ANON_KEY: 'your-anon-key-here',
  DASHBOARD_URL: 'https://app.jointhecrawl.com', // or http://localhost:3000
};
```

### 2. Create Extension Icons

Create an `icons/` folder with:
- `icon16.png` (16x16)
- `icon48.png` (48x48)  
- `icon128.png` (128x128)

Use the ◈ symbol in amber (#C17F24) on a light background.

### 3. Install in Chrome

1. Open `chrome://extensions/`
2. Enable "Developer mode" (top right toggle)
3. Click "Load unpacked"
4. Select this folder

### 4. Set up Dashboard

The extension expects a web dashboard at the configured URL. The dashboard handles:
- Login (Google OAuth via Supabase)
- Sending auth token to extension
- Full cache browsing and management

## How It Works

### Authentication Flow

1. User visits dashboard and logs in
2. Dashboard sends auth token to extension via `chrome.runtime.sendMessage`
3. Extension stores token in `chrome.storage.sync`
4. All API calls use this token

### Extension → Dashboard Communication

The dashboard must include this script to receive auth:

```javascript
// On dashboard, after Supabase login:
const EXTENSION_ID = 'your-extension-id'; // From chrome://extensions

// Send auth to extension
chrome.runtime.sendMessage(EXTENSION_ID, {
  type: 'AUTH_TOKEN',
  token: session.access_token,
  user: {
    id: user.id,
    email: user.email,
    username: profile.username
  }
});
```

### Cache Detection

- Extension checks URL against Supabase on every page load
- **Cold**: No caches on this domain
- **Warm**: Cache exists somewhere on this domain
- **Hot**: Cache on this exact page

### Beacon States

| State | Icon | Meaning |
|-------|------|---------|
| Cold | Gray ◈ | Nothing nearby |
| Warm | Pulsing amber ◈ | Cache on this domain |
| Hot | Glowing amber ◈ | Cache on this page! |
| Found | Green ✓ | Already found |

## Files

```
webcrawl-extension-v2/
├── manifest.json      # Extension config
├── background.js      # Service worker (API, auth)
├── content.js         # On-page beacon and cards
├── popup.html         # Extension popup UI
├── popup.js           # Popup logic
├── icons/             # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md          # This file
```

## API Endpoints Used

| Endpoint | Purpose |
|----------|---------|
| `/rest/v1/caches` | List/create caches |
| `/rest/v1/finds` | Log finds |
| `/rest/v1/profiles` | User stats |

## Permissions

- `storage` - Save auth token
- `activeTab` - Read current URL
- `tabs` - Track navigation
- `<all_urls>` - Check any URL for caches

## Development

For local development:

1. Set `DASHBOARD_URL` to `http://localhost:3000`
2. Make sure the `externally_connectable` in manifest.json includes localhost
3. Run your Next.js dashboard locally

## Troubleshooting

### Extension not detecting caches

1. Check Supabase URL and key in `background.js`
2. Open DevTools → Console on any page
3. Look for "Webcrawl:" errors

### Auth not syncing

1. Make sure dashboard is sending the token
2. Check `chrome.storage.sync` in DevTools (Extension → Inspect service worker)
3. Verify extension ID in dashboard matches

### Badge not updating

1. Refresh the page
2. Check if URL starts with `http://` or `https://`
3. Extension ignores `chrome://` pages
