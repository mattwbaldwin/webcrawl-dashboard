// Webcrawl Popup Script v2

const DASHBOARD_URL = 'https://webcrawl-dashboard.vercel.app';

document.addEventListener('DOMContentLoaded', async () => {
  await checkAuthAndRender();
  setupEventListeners();
});

async function checkAuthAndRender() {
  try {
    const { token, user, isLoggedIn } = await chrome.runtime.sendMessage({ type: 'GET_AUTH' });
    
    if (isLoggedIn && user) {
      showLoggedIn(user);
      await loadStats();
    } else {
      showLoggedOut();
    }
  } catch (error) {
    console.error('Error checking auth:', error);
    showLoggedOut();
    showError('Connection error');
  }
}

function showLoggedIn(user) {
  document.getElementById('logged-in').style.display = 'block';
  document.getElementById('logged-out').style.display = 'none';
  
  document.getElementById('username').textContent = '@' + (user.username || user.email?.split('@')[0] || 'crawler');
  document.getElementById('tier').textContent = (user.tier || 'scout').toUpperCase();
}

function showLoggedOut() {
  document.getElementById('logged-in').style.display = 'none';
  document.getElementById('logged-out').style.display = 'block';
}

async function loadStats() {
  try {
    const stats = await chrome.runtime.sendMessage({ type: 'GET_STATS' });
    
    if (stats) {
      document.getElementById('finds-count').textContent = stats.finds_count || 0;
      document.getElementById('drops-count').textContent = stats.drops_count || 0;
      document.getElementById('ftc-count').textContent = stats.ftc_count || 0;
    }
    
    showConnected();
  } catch (error) {
    console.error('Error loading stats:', error);
    showError('Failed to load stats');
  }
}

function showConnected() {
  document.getElementById('status-dot').className = 'status-dot';
  document.getElementById('status-text').textContent = 'Connected';
}

function showError(msg) {
  document.getElementById('status-dot').className = 'status-dot error';
  document.getElementById('status-text').textContent = msg;
}

function setupEventListeners() {
  // Dashboard button
  document.getElementById('btn-dashboard')?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'OPEN_DASHBOARD', path: '/dashboard' });
    window.close();
  });
  
  // Drop cache button
  document.getElementById('btn-drop')?.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab.url && tab.url.startsWith('http')) {
      // Open drop modal on the dashboard with URL pre-filled
      const encodedUrl = encodeURIComponent(tab.url);
      chrome.runtime.sendMessage({ 
        type: 'OPEN_DASHBOARD', 
        path: `/drop?url=${encodedUrl}` 
      });
      window.close();
    } else {
      showError('Cannot drop cache here');
    }
  });
  
  // Login button
  document.getElementById('btn-login')?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'OPEN_DASHBOARD', path: '/login' });
    window.close();
  });
}
