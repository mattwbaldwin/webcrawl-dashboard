// Webcrawl Content Script
// Handles on-page cache detection and display

(function() {
  // Prevent multiple injections
  if (window.__webcrawlLoaded) return;
  window.__webcrawlLoaded = true;

  const AMBER = '#C17F24';
  const GREEN = '#22c55e';
  
  // ============ Inject Styles ============
  
  const style = document.createElement('style');
  style.textContent = `
    @keyframes webcrawl-glow-hot {
      0%, 100% { box-shadow: 0 0 20px ${AMBER}, 0 0 40px ${AMBER}88; }
      50% { box-shadow: 0 0 30px ${AMBER}, 0 0 60px ${AMBER}aa; }
    }
    
    @keyframes webcrawl-glow-warm {
      0%, 100% { box-shadow: 0 0 10px ${AMBER}66; }
      50% { box-shadow: 0 0 20px ${AMBER}88; }
    }
    
    @keyframes webcrawl-pulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.08); }
    }
    
    @keyframes webcrawl-fade-in {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    #webcrawl-beacon {
      position: fixed;
      bottom: 24px;
      right: 24px;
      width: 56px;
      height: 56px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      cursor: pointer;
      z-index: 2147483647;
      transition: all 0.4s ease;
      border: none;
      font-family: system-ui, sans-serif;
    }
    
    #webcrawl-beacon.cold {
      background: #f5f5f5;
      color: #aaa;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    
    #webcrawl-beacon.warm {
      background: #FEF8F0;
      color: ${AMBER};
      border: 2px solid ${AMBER}66;
      animation: webcrawl-glow-warm 2s ease-in-out infinite, webcrawl-pulse 2.5s ease-in-out infinite;
    }
    
    #webcrawl-beacon.hot {
      background: ${AMBER};
      color: white;
      animation: webcrawl-glow-hot 1.2s ease-in-out infinite, webcrawl-pulse 1s ease-in-out infinite;
    }
    
    #webcrawl-beacon.found {
      background: ${GREEN};
      color: white;
      box-shadow: 0 4px 20px rgba(34, 197, 94, 0.4);
    }
    
    #webcrawl-toast {
      position: fixed;
      bottom: 100px;
      right: 24px;
      background: white;
      padding: 14px 20px;
      border-radius: 12px;
      font-family: system-ui, sans-serif;
      font-size: 14px;
      z-index: 2147483647;
      animation: webcrawl-fade-in 0.3s ease;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
      max-width: 280px;
    }
    
    #webcrawl-toast.warm {
      background: #FEF8F0;
      border: 1px solid ${AMBER}40;
      color: #92550e;
    }
    
    #webcrawl-toast.hot {
      background: ${AMBER};
      color: white;
    }
    
    #webcrawl-cache-card {
      position: fixed;
      bottom: 100px;
      right: 24px;
      width: 300px;
      background: white;
      border-radius: 16px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.2);
      z-index: 2147483647;
      animation: webcrawl-fade-in 0.3s ease;
      overflow: hidden;
      font-family: system-ui, sans-serif;
    }
    
    #webcrawl-cache-card .header {
      background: linear-gradient(135deg, ${AMBER}, #D4922E);
      color: white;
      padding: 20px;
      text-align: center;
    }
    
    #webcrawl-cache-card .header.found {
      background: linear-gradient(135deg, ${GREEN}, #16a34a);
    }
    
    #webcrawl-cache-card .icon {
      width: 48px;
      height: 48px;
      background: rgba(255,255,255,0.2);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 10px;
      font-size: 22px;
    }
    
    #webcrawl-cache-card .label {
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 1px;
      opacity: 0.9;
    }
    
    #webcrawl-cache-card .name {
      font-size: 18px;
      font-weight: 600;
      margin-top: 4px;
    }
    
    #webcrawl-cache-card .body {
      padding: 16px;
    }
    
    #webcrawl-cache-card .message {
      font-size: 13px;
      color: #555;
      line-height: 1.5;
      font-style: italic;
      padding: 12px;
      background: #FDF4E7;
      border-radius: 8px;
      margin-bottom: 12px;
    }
    
    #webcrawl-cache-card .meta {
      font-size: 12px;
      color: #888;
      display: flex;
      gap: 12px;
      margin-bottom: 12px;
    }
    
    #webcrawl-cache-card .btn {
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      background: ${AMBER};
      color: white;
    }
    
    #webcrawl-cache-card .btn:hover {
      background: #a86b1d;
    }
    
    #webcrawl-cache-card .btn:disabled {
      background: #ccc;
      cursor: default;
    }
    
    #webcrawl-cache-card .btn.found {
      background: ${GREEN};
    }
    
    #webcrawl-cache-card .close {
      position: absolute;
      top: 10px;
      right: 10px;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      border: none;
      background: rgba(255,255,255,0.2);
      color: white;
      font-size: 18px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    #webcrawl-cache-card .status-msg {
      text-align: center;
      font-size: 12px;
      color: #888;
      margin-top: 8px;
    }
  `;
  document.head.appendChild(style);

  // ============ State ============
  
  let currentStatus = 'cold';
  let currentCache = null;
  let alreadyFound = false;
  let cardVisible = false;

  // ============ Create Beacon ============
  
  const beacon = document.createElement('button');
  beacon.id = 'webcrawl-beacon';
  beacon.className = 'cold';
  beacon.textContent = '◈';
  beacon.addEventListener('click', handleBeaconClick);
  document.body.appendChild(beacon);

  // ============ Check URL on Load ============
  
  checkUrl();
  
  // Re-check on navigation (SPAs)
  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      checkUrl();
    }
  }, 500);

  // ============ Listen for Messages ============
  
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'URL_STATUS') {
      updateStatus(msg.status, msg.cache, msg.alreadyFound);
    }
  });

  // ============ Functions ============
  
  async function checkUrl() {
    try {
      const result = await chrome.runtime.sendMessage({
        type: 'CHECK_URL',
        url: location.href
      });
      updateStatus(result.status, result.cache, result.alreadyFound);
    } catch (e) {
      // Extension context invalidated
      beacon.remove();
    }
  }
  
  function updateStatus(status, cache, found) {
    currentStatus = status;
    currentCache = cache;
    alreadyFound = found;
    
    // Update beacon
    beacon.className = '';
    if (found) {
      beacon.classList.add('found');
      beacon.textContent = '✓';
    } else {
      beacon.classList.add(status);
      beacon.textContent = '◈';
    }
    
    // Auto-show card when hot
    if (status === 'hot' && !found && !cardVisible) {
      showCacheCard();
    }
    
    // Hide card if navigated away
    if (status !== 'hot' && !found && cardVisible) {
      hideCacheCard();
    }
  }
  
  function handleBeaconClick() {
    if (cardVisible) {
      hideCacheCard();
    } else if (currentStatus === 'hot' || alreadyFound) {
      showCacheCard();
    } else if (currentStatus === 'warm') {
      showToast('🔥 Cache nearby! Keep exploring this site...', 'warm');
    } else {
      showToast('No caches nearby. Keep exploring!', 'cold');
    }
  }
  
  function showToast(message, type) {
    // Remove existing
    const existing = document.getElementById('webcrawl-toast');
    if (existing) existing.remove();
    
    const toast = document.createElement('div');
    toast.id = 'webcrawl-toast';
    toast.className = type;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => toast.remove(), 3000);
  }
  
  function showCacheCard() {
    if (!currentCache) return;
    
    hideCacheCard();
    
    const card = document.createElement('div');
    card.id = 'webcrawl-cache-card';
    
    const headerClass = alreadyFound ? 'header found' : 'header';
    const icon = alreadyFound ? '✓' : '◈';
    const label = alreadyFound ? 'Already Found' : 'Cache Found!';
    
    card.innerHTML = `
      <button class="close">×</button>
      <div class="${headerClass}">
        <div class="icon">${icon}</div>
        <div class="label">${label}</div>
        <div class="name">${escapeHtml(currentCache.name)}</div>
      </div>
      <div class="body">
        <div class="message">"${escapeHtml(currentCache.message)}"</div>
        <div class="meta">
          <span>👥 ${currentCache.finds_count || 0} finds</span>
          <span>${currentCache.owner_display || '📍 by @unknown'}</span>
        </div>
        ${alreadyFound ? 
          '<div class="status-msg">You\'ve already logged this find</div>' :
          '<button class="btn" id="webcrawl-log-btn">✓ Log Find</button>'
        }
      </div>
    `;
    
    document.body.appendChild(card);
    cardVisible = true;
    
    // Event listeners
    card.querySelector('.close').addEventListener('click', hideCacheCard);
    
    const logBtn = card.querySelector('#webcrawl-log-btn');
    if (logBtn) {
      logBtn.addEventListener('click', handleLogFind);
    }
  }
  
  function hideCacheCard() {
    const card = document.getElementById('webcrawl-cache-card');
    if (card) card.remove();
    cardVisible = false;
  }
  
  async function handleLogFind() {
    const btn = document.getElementById('webcrawl-log-btn');
    if (!btn || !currentCache) return;
    
    btn.disabled = true;
    btn.textContent = 'Logging...';
    
    try {
      const result = await chrome.runtime.sendMessage({
        type: 'LOG_FIND',
        cacheId: currentCache.id
      });
      
      if (result.success) {
        alreadyFound = true;
        
        // Update beacon
        beacon.className = 'found';
        beacon.textContent = '✓';
        
        // Update card
        const header = document.querySelector('#webcrawl-cache-card .header');
        const icon = document.querySelector('#webcrawl-cache-card .icon');
        const label = document.querySelector('#webcrawl-cache-card .label');
        
        if (header) header.classList.add('found');
        if (icon) icon.textContent = '✓';
        if (label) label.textContent = result.isFtc ? '🏆 First to Crawl!' : 'Logged!';
        
        btn.textContent = result.isFtc ? '🏆 First to Crawl!' : '✓ Logged!';
        btn.classList.add('found');
      } else {
        btn.textContent = result.error || 'Error';
        setTimeout(() => {
          btn.textContent = '✓ Log Find';
          btn.disabled = false;
        }, 2000);
      }
    } catch (e) {
      btn.textContent = 'Error - try popup';
      setTimeout(() => {
        btn.textContent = '✓ Log Find';
        btn.disabled = false;
      }, 2000);
    }
  }
  
  function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
})();
