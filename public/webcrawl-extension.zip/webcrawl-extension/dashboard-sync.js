// Dashboard Auth Sync Content Script
// Runs on the dashboard domain to pick up auth tokens

(function() {
  console.log('[Webcrawl] Content script loaded on:', window.location.hostname);
  
  // Only run on the dashboard
  if (!window.location.hostname.includes('webcrawl') && 
      !window.location.hostname.includes('vercel.app') &&
      !window.location.hostname.includes('localhost')) {
    console.log('[Webcrawl] Not a dashboard page, skipping');
    return;
  }

  console.log('[Webcrawl] Dashboard detected, checking for auth...');

  // Check localStorage for auth data
  function checkAndSyncAuth() {
    console.log('[Webcrawl] Checking localStorage...');
    const authJson = localStorage.getItem('webcrawl_extension_auth');
    console.log('[Webcrawl] Found in localStorage:', authJson ? 'YES (' + authJson.length + ' chars)' : 'NO');
    
    if (authJson) {
      try {
        const auth = JSON.parse(authJson);
        console.log('[Webcrawl] Parsed auth, has access_token:', !!auth.access_token, 'has user:', !!auth.user);
        
        if (auth.access_token && auth.user) {
          console.log('[Webcrawl] Sending SET_AUTH to background...');
          
          // Send to background script
          chrome.runtime.sendMessage({ 
            type: 'SET_AUTH', 
            auth: auth 
          }, (response) => {
            console.log('[Webcrawl] SET_AUTH response:', response);
            if (chrome.runtime.lastError) {
              console.error('[Webcrawl] Runtime error:', chrome.runtime.lastError);
            }
            if (response?.success) {
              console.log('[Webcrawl] Auth synced successfully!');
            }
          });
        }
      } catch (e) {
        console.error('[Webcrawl] Failed to parse auth:', e);
      }
    } else {
      console.log('[Webcrawl] No auth in localStorage yet');
    }
  }

  // Check immediately
  checkAndSyncAuth();

  // Also listen for the custom event
  window.addEventListener('webcrawl_auth_ready', (e) => {
    console.log('[Webcrawl] Received webcrawl_auth_ready event');
    const auth = e.detail;
    if (auth?.access_token) {
      console.log('[Webcrawl] Sending SET_AUTH from event...');
      chrome.runtime.sendMessage({ 
        type: 'SET_AUTH', 
        auth: auth 
      }, (response) => {
        console.log('[Webcrawl] SET_AUTH (event) response:', response);
        if (response?.success) {
          console.log('[Webcrawl] Auth synced via event!');
        }
      });
    }
  });

  // Check periodically in case page updates
  setTimeout(checkAndSyncAuth, 1000);
  setTimeout(checkAndSyncAuth, 3000);
  setTimeout(checkAndSyncAuth, 5000);
})();
