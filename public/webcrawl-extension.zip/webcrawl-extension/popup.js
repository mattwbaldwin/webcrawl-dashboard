// Webcrawl Popup Script

let currentUrl = '';
let currentCache = null;
let isLoggedIn = false;
let userProfile = null;

// ============ Init ============

document.addEventListener('DOMContentLoaded', init);

async function init() {
  // Get current tab URL
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentUrl = tab?.url || '';
  
  // Check auth status
  const { auth } = await chrome.runtime.sendMessage({ type: 'GET_AUTH' });
  
  if (auth?.user) {
    isLoggedIn = true;
    userProfile = auth.profile || { username: auth.user.email?.split('@')[0] };
    showMainSection(auth);
  } else {
    showSignInSection();
  }
  
  // Set up event listeners
  setupEventListeners();
}

// ============ UI State ============

function showSection(sectionId) {
  document.querySelectorAll('.auth-section').forEach(s => s.classList.remove('active'));
  document.getElementById(sectionId).classList.add('active');
}

function showSignInSection() {
  showSection('sign-in-section');
  document.getElementById('header-subtitle').textContent = 'Sign in to play';
}

async function showMainSection(auth) {
  showSection('main-section');
  
  // Update user info
  document.getElementById('user-name').textContent = '@' + (userProfile?.username || 'crawler');
  document.getElementById('header-subtitle').textContent = 'Happy hunting!';
  
  // Update URLs
  document.getElementById('current-url').textContent = currentUrl || 'No URL';
  document.getElementById('drop-url').textContent = currentUrl || 'No URL';
  
  // Check current page status
  await checkCurrentPage();
  
  // Load user stats
  loadUserStats();
}

async function checkCurrentPage() {
  if (!currentUrl || currentUrl.startsWith('chrome')) {
    updateStatus('cold', 'Navigate to a webpage to start hunting');
    showPanel('normal-panel');
    return;
  }
  
  const result = await chrome.runtime.sendMessage({ type: 'CHECK_URL', url: currentUrl });
  
  if (result.status === 'hot' && result.cache) {
    currentCache = result.cache;
    if (result.alreadyFound) {
      updateStatus('found', 'You already found this cache!');
      showCacheCard(result.cache, true);
    } else {
      updateStatus('hot', '🔥 Cache found on this page!');
      showCacheCard(result.cache, false);
    }
  } else if (result.status === 'warm') {
    updateStatus('warm', 'Cache nearby on this domain...');
    showPanel('normal-panel');
  } else {
    updateStatus('cold', 'No caches nearby');
    showPanel('normal-panel');
  }
}

function updateStatus(status, text) {
  const dot = document.getElementById('status-dot');
  dot.className = 'status-dot ' + status;
  document.getElementById('status-text').textContent = text;
}

function showPanel(panelId) {
  document.querySelectorAll('#main-section .panel').forEach(p => p.classList.remove('active'));
  document.getElementById(panelId).classList.add('active');
}

function showCacheCard(cache, alreadyFound) {
  showPanel('cache-found-panel');
  
  const header = document.getElementById('cache-header');
  const icon = document.getElementById('cache-icon');
  const label = document.getElementById('cache-label');
  const logBtn = document.getElementById('log-find-btn');
  
  document.getElementById('cache-name').textContent = cache.name;
  document.getElementById('cache-message').textContent = '"' + cache.message + '"';
  document.getElementById('cache-finds').textContent = '👥 ' + (cache.finds_count || 0) + ' finds';
  document.getElementById('cache-owner').textContent = '📍 ' + (cache.owner_display || 'by @unknown');
  
  if (alreadyFound) {
    header.classList.add('found');
    icon.textContent = '✓';
    label.textContent = 'Already Found';
    logBtn.textContent = '✓ Already Logged';
    logBtn.disabled = true;
    logBtn.classList.add('btn-secondary');
    logBtn.classList.remove('btn-primary');
  } else {
    header.classList.remove('found');
    icon.textContent = '◈';
    label.textContent = 'Cache Found!';
    logBtn.textContent = '✓ Log Find';
    logBtn.disabled = false;
    logBtn.classList.remove('btn-secondary');
    logBtn.classList.add('btn-primary');
  }
}

async function loadUserStats() {
  const { finds } = await chrome.runtime.sendMessage({ type: 'GET_USER_FINDS' });
  document.getElementById('user-stats').textContent = `${finds?.length || 0} caches found`;
}

// ============ Event Listeners ============

function setupEventListeners() {
  // Sign in buttons
  document.getElementById('google-sign-in').addEventListener('click', handleGoogleSignIn);
  document.getElementById('dashboard-link').addEventListener('click', openDashboard);
  
  // Sign out
  document.getElementById('sign-out').addEventListener('click', handleSignOut);
  
  // Tab switching
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      const tabName = tab.dataset.tab;
      document.getElementById('hunt-panel').classList.toggle('active', tabName === 'hunt');
      document.getElementById('drop-panel').classList.toggle('active', tabName === 'drop');
    });
  });
  
  // Log find
  document.getElementById('log-find-btn').addEventListener('click', handleLogFind);
  
  // Drop cache
  document.getElementById('drop-cache-btn').addEventListener('click', handleDropCache);
  
  // Open dashboard
  document.getElementById('open-dashboard').addEventListener('click', openDashboard);
}

// ============ Auth Handlers ============

async function handleGoogleSignIn() {
  // For now, redirect to dashboard for OAuth
  // Full extension OAuth requires more setup
  chrome.tabs.create({ url: CONFIG.DASHBOARD_URL + '/login?from=extension' });
  window.close();
}

function openDashboard() {
  chrome.tabs.create({ url: CONFIG.DASHBOARD_URL });
  window.close();
}

async function handleSignOut() {
  await chrome.runtime.sendMessage({ type: 'SIGN_OUT' });
  isLoggedIn = false;
  userProfile = null;
  showSignInSection();
}

// ============ Cache Handlers ============

async function handleLogFind() {
  if (!currentCache) return;
  
  const btn = document.getElementById('log-find-btn');
  const msg = document.getElementById('find-message');
  
  btn.disabled = true;
  btn.textContent = 'Logging...';
  
  const result = await chrome.runtime.sendMessage({
    type: 'LOG_FIND',
    cacheId: currentCache.id
  });
  
  if (result.success) {
    msg.className = 'message success';
    if (result.isFtc) {
      msg.textContent = '🏆 First to Crawl! You found it first!';
    } else if (result.alreadyLogged) {
      msg.textContent = 'Already logged!';
    } else {
      msg.textContent = '✓ Find logged successfully!';
    }
    
    // Update UI to show found state
    showCacheCard(currentCache, true);
    updateStatus('found', 'You found this cache!');
    
    // Refresh tab badge
    chrome.runtime.sendMessage({ type: 'REFRESH_TAB' });
  } else {
    msg.className = 'message error';
    msg.textContent = result.error || 'Failed to log find';
    btn.disabled = false;
    btn.textContent = '✓ Log Find';
  }
}

async function handleDropCache() {
  const name = document.getElementById('cache-name-input').value.trim();
  const clue = document.getElementById('cache-clue-input').value.trim();
  const message = document.getElementById('cache-message-input').value.trim();
  const hint = document.getElementById('cache-hint-input').value.trim();
  
  const msg = document.getElementById('drop-message');
  
  if (!name || !clue || !message) {
    msg.className = 'message error';
    msg.textContent = 'Please fill in all required fields';
    return;
  }
  
  if (!currentUrl || currentUrl.startsWith('chrome')) {
    msg.className = 'message error';
    msg.textContent = 'Navigate to a webpage first';
    return;
  }
  
  const btn = document.getElementById('drop-cache-btn');
  btn.disabled = true;
  btn.textContent = 'Dropping...';
  
  const result = await chrome.runtime.sendMessage({
    type: 'DROP_CACHE',
    url: currentUrl,
    name,
    clue,
    message,
    hint,
    difficulty: 2
  });
  
  if (result.success) {
    msg.className = 'message success';
    msg.textContent = '📍 Cache dropped! Others can now find it.';
    
    // Clear form
    document.getElementById('cache-name-input').value = '';
    document.getElementById('cache-clue-input').value = '';
    document.getElementById('cache-message-input').value = '';
    document.getElementById('cache-hint-input').value = '';
    
    // Update status
    updateStatus('hot', 'Your cache is now live!');
    
    // Refresh
    setTimeout(() => checkCurrentPage(), 1000);
  } else {
    msg.className = 'message error';
    msg.textContent = result.error || 'Failed to drop cache';
  }
  
  btn.disabled = false;
  btn.textContent = '📍 Drop Cache';
}

// ============ Listen for auth from dashboard ============

// Check for auth token passed from dashboard
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.auth?.newValue) {
    // Auth was set (probably from dashboard)
    init();
  }
});
