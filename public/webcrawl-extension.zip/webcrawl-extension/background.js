// Webcrawl Background Service Worker
// Handles auth, cache detection, and Supabase sync

// Import config (will be injected)
importScripts('config.js');

const SUPABASE_URL = CONFIG?.SUPABASE_URL || '';
const SUPABASE_ANON_KEY = CONFIG?.SUPABASE_ANON_KEY || '';

// ============ URL Utilities ============

function normalizeUrl(url) {
  try {
    const u = new URL(url);
    // Remove tracking params, normalize
    const cleanParams = new URLSearchParams();
    u.searchParams.forEach((v, k) => {
      if (!['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'fbclid', 'gclid', 'ref'].includes(k)) {
        cleanParams.set(k, v);
      }
    });
    u.search = cleanParams.toString();
    u.hash = '';
    return (u.origin + u.pathname).replace(/\/$/, '').toLowerCase() + (u.search ? '?' + u.search : '');
  } catch {
    return url.toLowerCase();
  }
}

function getDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

async function hashUrl(url) {
  const normalized = normalizeUrl(url);
  const encoder = new TextEncoder();
  const data = encoder.encode(normalized);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// ============ Auth Management ============

async function getAuth() {
  const { auth } = await chrome.storage.local.get('auth');
  return auth || null;
}

async function setAuth(authData) {
  await chrome.storage.local.set({ auth: authData });
}

async function clearAuth() {
  await chrome.storage.local.remove('auth');
}

async function getAuthHeaders() {
  const auth = await getAuth();
  if (!auth?.access_token) return null;
  return {
    'Authorization': `Bearer ${auth.access_token}`,
    'apikey': SUPABASE_ANON_KEY,
    'Content-Type': 'application/json'
  };
}

// ============ Supabase API ============

async function supabaseRequest(endpoint, options = {}) {
  const headers = await getAuthHeaders();
  if (!headers && options.requireAuth !== false) {
    return { error: 'Not authenticated' };
  }
  
  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/${endpoint}`, {
      ...options,
      headers: {
        ...headers,
        ...(options.headers || {})
      }
    });
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: response.statusText }));
      return { error: error.message || 'Request failed' };
    }
    
    const data = await response.json().catch(() => null);
    return { data };
  } catch (e) {
    return { error: e.message };
  }
}

// ============ Cache Operations ============

async function fetchCachesForUrl(url) {
  const urlHash = await hashUrl(url);
  const domain = getDomain(url);
  
  // Get caches for exact URL match
  const { data: exactMatches } = await supabaseRequest(
    `caches?url_hash=eq.${urlHash}&is_active=eq.true&select=*`,
    { requireAuth: false, headers: { 'apikey': SUPABASE_ANON_KEY } }
  );
  
  // Get caches for same domain (for warm indicator)
  const { data: domainMatches } = await supabaseRequest(
    `caches?url=ilike.*${domain}*&is_active=eq.true&select=id,url`,
    { requireAuth: false, headers: { 'apikey': SUPABASE_ANON_KEY } }
  );
  
  return {
    exactMatches: exactMatches || [],
    domainHasCaches: (domainMatches || []).length > 0
  };
}

async function getUserFinds() {
  const auth = await getAuth();
  if (!auth?.user?.id) return [];
  
  const { data } = await supabaseRequest(
    `finds?user_id=eq.${auth.user.id}&select=cache_id`
  );
  return (data || []).map(f => f.cache_id);
}

async function checkUrl(url) {
  // Fetch from Supabase
  const { exactMatches, domainHasCaches } = await fetchCachesForUrl(url);
  const userFinds = await getUserFinds();
  
  if (exactMatches.length > 0) {
    const cache = exactMatches[0];
    const alreadyFound = userFinds.includes(cache.id);
    return { status: 'hot', cache, alreadyFound };
  }
  
  if (domainHasCaches) {
    return { status: 'warm', cache: null, alreadyFound: false };
  }
  
  return { status: 'cold', cache: null, alreadyFound: false };
}

async function logFind(cacheId) {
  const auth = await getAuth();
  if (!auth?.user?.id) {
    return { success: false, error: 'Not logged in' };
  }
  
  // Check if FTC (first to crawl)
  const { data: existingFinds } = await supabaseRequest(
    `finds?cache_id=eq.${cacheId}&select=id&limit=1`,
    { requireAuth: false, headers: { 'apikey': SUPABASE_ANON_KEY } }
  );
  const isFtc = !existingFinds || existingFinds.length === 0;
  
  // Insert find
  const { data, error } = await supabaseRequest('finds', {
    method: 'POST',
    body: JSON.stringify({
      cache_id: cacheId,
      user_id: auth.user.id,
      is_ftc: isFtc,
      log_text: ''
    }),
    headers: { 'Prefer': 'return=representation' }
  });
  
  if (error) {
    // Check if duplicate
    if (error.includes('duplicate') || error.includes('23505')) {
      return { success: true, alreadyLogged: true };
    }
    return { success: false, error };
  }
  
  // Update cache finds_count
  await supabaseRequest(`rpc/increment_cache_finds`, {
    method: 'POST',
    body: JSON.stringify({ cache_uuid: cacheId })
  });
  
  return { success: true, find: data?.[0], isFtc };
}

async function dropCache(url, name, clue, message, hint, difficulty) {
  const auth = await getAuth();
  if (!auth?.user?.id) {
    return { success: false, error: 'Not logged in' };
  }
  
  const urlHash = await hashUrl(url);
  const normalizedUrl = normalizeUrl(url);
  
  const { data, error } = await supabaseRequest('caches', {
    method: 'POST',
    body: JSON.stringify({
      url: normalizedUrl,
      url_hash: urlHash,
      name,
      clue,
      message,
      hint: hint || null,
      difficulty: difficulty || 2,
      owner_id: auth.user.id,
      owner_display: '@' + (auth.profile?.username || 'anonymous'),
      is_active: true,
      is_seed: false,
      finds_count: 0
    }),
    headers: { 'Prefer': 'return=representation' }
  });
  
  if (error) {
    return { success: false, error };
  }
  
  return { success: true, cache: data?.[0] };
}

// ============ Badge Updates ============

function updateBadge(tabId, status, alreadyFound = false) {
  const colors = {
    cold: '#888888',
    warm: '#F59E0B',
    hot: '#C17F24',
    found: '#22c55e'
  };
  const text = {
    cold: '',
    warm: '~',
    hot: '!',
    found: '✓'
  };
  
  const state = alreadyFound ? 'found' : status;
  
  chrome.action.setBadgeBackgroundColor({ color: colors[state], tabId });
  chrome.action.setBadgeText({ text: text[state], tabId });
}

// ============ Event Listeners ============

// Tab updates
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && !tab.url.startsWith('chrome')) {
    try {
      const result = await checkUrl(tab.url);
      updateBadge(tabId, result.status, result.alreadyFound);
      
      // Notify content script
      chrome.tabs.sendMessage(tabId, { type: 'URL_STATUS', ...result }).catch(() => {});
    } catch (e) {
      console.error('Error checking URL:', e);
    }
  }
});

// Tab activation
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab.url && !tab.url.startsWith('chrome')) {
      const result = await checkUrl(tab.url);
      updateBadge(activeInfo.tabId, result.status, result.alreadyFound);
    }
  } catch (e) {
    console.error('Error on tab activation:', e);
  }
});

// Message handling
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handleMessage(msg, sender).then(sendResponse);
  return true;
});

async function handleMessage(msg, sender) {
  switch (msg.type) {
    case 'GET_AUTH': {
      const auth = await getAuth();
      return { auth };
    }
    
    case 'SET_AUTH': {
      console.log('[Webcrawl BG] SET_AUTH received, auth has token:', !!msg.auth?.access_token);
      await setAuth(msg.auth);
      console.log('[Webcrawl BG] Auth stored successfully');
      return { success: true };
    }
    
    case 'SIGN_OUT': {
      await clearAuth();
      return { success: true };
    }
    
    case 'CHECK_URL': {
      return await checkUrl(msg.url);
    }
    
    case 'LOG_FIND': {
      return await logFind(msg.cacheId);
    }
    
    case 'DROP_CACHE': {
      return await dropCache(
        msg.url,
        msg.name,
        msg.clue,
        msg.message,
        msg.hint,
        msg.difficulty
      );
    }
    
    case 'GET_USER_FINDS': {
      const finds = await getUserFinds();
      return { finds };
    }
    
    case 'REFRESH_TAB': {
      if (sender.tab?.id) {
        const result = await checkUrl(sender.tab.url);
        updateBadge(sender.tab.id, result.status, result.alreadyFound);
        return result;
      }
      return { error: 'No tab' };
    }
    
    default:
      return { error: 'Unknown message type' };
  }
}

console.log('Webcrawl background service worker loaded');
