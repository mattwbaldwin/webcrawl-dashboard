# Webcrawl Extension v3

Browser extension for the Webcrawl treasure hunting game.

## Features

- 🔥 Beacon glows when near a cache (cold → warm → hot)
- ✓ Log finds directly from the extension
- 📍 Drop new caches on any page
- 🔄 Syncs with Supabase backend

## Setup

### 1. Configure Supabase

Edit `config.js` and add your Supabase credentials:

```javascript
const CONFIG = {
  SUPABASE_URL: 'https://your-project.supabase.co',
  SUPABASE_ANON_KEY: 'your-anon-key',
  DASHBOARD_URL: 'https://your-dashboard.vercel.app'
};
```

### 2. Create Icons

You need PNG icons at 16x16, 48x48, and 128x128 pixels.

Quick option: Use any image editor to create amber-colored icons with the ◈ symbol, or convert the included SVG.

### 3. Install in Chrome

1. Open Chrome → `chrome://extensions/`
2. Enable "Developer mode" (top right)
3. Click "Load unpacked"
4. Select this folder

### 4. Sign In

Click the extension icon → Sign in via the dashboard.

## How Auth Works

For beta testing, auth works via the dashboard:

1. User signs in on dashboard (Google OAuth)
2. Dashboard stores auth token
3. Extension reads token when user clicks "Sign in on Dashboard"

For production, we'll add direct OAuth in the extension popup.

## Database Requirements

The extension expects these Supabase tables:

- `caches` - Cache records with url_hash, name, clue, message, etc.
- `finds` - User find records
- `profiles` - User profiles

Plus this RPC function:

```sql
CREATE OR REPLACE FUNCTION increment_cache_finds(cache_uuid UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE caches SET finds_count = finds_count + 1 WHERE id = cache_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

## Files

- `manifest.json` - Extension configuration
- `config.js` - Supabase credentials (edit this!)
- `background.js` - Service worker for API calls
- `popup.html/js` - Extension popup UI
- `content.js` - On-page beacon and cache cards
- `icons/` - Extension icons

## Status Indicators

| Beacon | Meaning |
|--------|---------|
| Gray | No caches on this domain |
| Amber pulse | Cache somewhere on this domain |
| Amber glow | Cache on THIS page! |
| Green ✓ | Already found |
