-- Webcrawl Additional Supabase Setup
-- Run this in the Supabase SQL Editor

-- Function to increment cache finds count
CREATE OR REPLACE FUNCTION increment_cache_finds(cache_uuid UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE caches SET finds_count = finds_count + 1 WHERE id = cache_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RLS policy for finds table - allow insert
DROP POLICY IF EXISTS "Users can insert own finds" ON finds;
CREATE POLICY "Users can insert own finds"
ON finds FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- RLS policy for finds table - allow read own
DROP POLICY IF EXISTS "Users can read own finds" ON finds;
CREATE POLICY "Users can read own finds"
ON finds FOR SELECT
USING (auth.uid() = user_id);

-- RLS policy for finds - allow public read for counting
DROP POLICY IF EXISTS "Public can count finds" ON finds;
CREATE POLICY "Public can count finds"
ON finds FOR SELECT
USING (true);

-- RLS policy for caches - allow insert for authenticated users
DROP POLICY IF EXISTS "Authenticated can insert caches" ON caches;
CREATE POLICY "Authenticated can insert caches"
ON caches FOR INSERT
WITH CHECK (auth.role() = 'authenticated');

-- RLS policy for caches - allow update for owner
DROP POLICY IF EXISTS "Owners can update caches" ON caches;
CREATE POLICY "Owners can update caches"
ON caches FOR UPDATE
USING (auth.uid() = owner_id);

-- RLS policy for caches - allow public read
DROP POLICY IF EXISTS "Public can read active caches" ON caches;
CREATE POLICY "Public can read active caches"
ON caches FOR SELECT
USING (is_active = true);

-- Grant execute on function
GRANT EXECUTE ON FUNCTION increment_cache_finds TO authenticated;
GRANT EXECUTE ON FUNCTION increment_cache_finds TO anon;
