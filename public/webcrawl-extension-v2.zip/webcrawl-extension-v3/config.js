// Webcrawl Extension Config
// Replace these with your actual Supabase credentials

const CONFIG = {
  SUPABASE_URL: 'https://ihecqpuwfbjnhazgtbqp.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_g7Svdy-OcefU2pgp1gTvRg_Q-ZT8VRH',
  DASHBOARD_URL: 'https://webcrawl-dashboard.vercel.app/'
};

// Make available globally
if (typeof window !== 'undefined') {
  window.WEBCRAWL_CONFIG = CONFIG;
}
