// Webcrawl Background Service Worker v2
// With Supabase integration

// ============================================
// CONFIGURATION - UPDATE THESE
// ============================================

const CONFIG = {
  SUPABASE_URL: 'https://ihecqpuwfbjnhazgtbqp.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_g7Svdy-OcefU2pgp1gTvRg_Q-ZT8VRH',
  DASHBOARD_URL: 'https://webcrawl-dashboard.vercel.app',
};

// ============================================
// URL UTILITIES
// ============================================

function normalizeUrl(url) {
  try {
    const u = new URL(url);
    let normalized = (u.origin + u.pathname).replace(/\/$/, '').toLowerCase();
    return normalized;
  } catch {
    return url.toLowerCase();
  }
}

function getDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

async function hashUrl(url) {
  const normalized = normalizeUrl(url);
  const encoder = new TextEncoder();
  const data = encoder.encode(normalized);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// ============================================
// AUTH MANAGEMENT
// ============================================

async function getAuthToken() {
  const { authToken } = await chrome.storage.sync.get('authToken');
  return authToken || null;
}

async function getUser() {
  const { user } = await chrome.storage.sync.get('user');
  return user || null;
}

async function setAuth(token, user) {
  await chrome.storage.sync.set({ authToken: token, user });
  console.log('Auth set for user:', user?.username);
}

async function clearAuth() {
  await chrome.storage.sync.remove(['authToken', 'user']);
  console.log('Auth cleared');
}

async function isLoggedIn() {
  const token = await getAuthToken();
  return !!token;
}

// ============================================
// SUPABASE API CALLS
// ============================================

async function apiRequest(endpoint, options = {}) {
  const token = await getAuthToken();
  
  const headers = {
    'Content-Type': 'application/json',
    'apikey': CONFIG.SUPABASE_ANON_KEY,
    ...options.headers
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  try {
    const response = await fetch(`${CONFIG.SUPABASE_URL}${endpoint}`, {
      ...options,
      headers
    });
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.message || error.error || `API error: ${response.status}`);
    }
    
    const text = await response.text();
    return text ? JSON.parse(text) : null;
  } catch (error) {
    console.error('API request failed:', endpoint, error);
    throw error;
  }
}

// ============================================
// CACHE OPERATIONS
// ============================================

async function checkUrlForCaches(url) {
  // Skip non-http URLs
  if (!url || !url.startsWith('http')) {
    return { status: 'cold', cache: null, alreadyFound: false, cacheCount: 0 };
  }

  const urlHash = await hashUrl(url);
  const domain = getDomain(url);
  
  try {
    // Check for exact URL match
    const exactMatch = await apiRequest(
      `/rest/v1/caches?url_hash=eq.${urlHash}&is_active=eq.true&select=id,name,clue,message,hint,difficulty,finds_count,owner_display,trail_id,trail_order`
    );
    
    if (exactMatch && exactMatch.length > 0) {
      const cache = exactMatch[0];
      
      // Check if user already found this cache (server-side or locally)
      let alreadyFound = await isFoundLocally(cache.id);
      
      // Also check server if logged in
      if (!alreadyFound) {
        const user = await getUser();
        if (user && user.id) {
          try {
            const finds = await apiRequest(
              `/rest/v1/finds?cache_id=eq.${cache.id}&user_id=eq.${user.id}&select=id`
            );
            alreadyFound = finds && finds.length > 0;
          } catch (e) {
            // Ignore find check errors
          }
        }
      }
      
      return { 
        status: 'hot', 
        cache: cache, 
        alreadyFound,
        cacheCount: exactMatch.length
      };
    }
    
    // Check for same domain (warm)
    // Use domain matching - escape special chars
    const escapedDomain = domain.replace(/\./g, '\\.');
    const domainCaches = await apiRequest(
      `/rest/v1/caches?url=ilike.*${encodeURIComponent(domain)}*&is_active=eq.true&select=id`
    );
    
    if (domainCaches && domainCaches.length > 0) {
      return { 
        status: 'warm', 
        cache: null, 
        alreadyFound: false,
        cacheCount: domainCaches.length
      };
    }
    
    return { status: 'cold', cache: null, alreadyFound: false, cacheCount: 0 };
    
  } catch (error) {
    console.error('Error checking URL:', error);
    return { status: 'cold', cache: null, alreadyFound: false, cacheCount: 0 };
  }
}

async function logFind(cacheId, logText = '') {
  const user = await getUser();
  
  // If logged in, try to log to Supabase
  if (user && user.id) {
    try {
      const result = await apiRequest('/rest/v1/finds', {
        method: 'POST',
        headers: {
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          cache_id: cacheId,
          user_id: user.id,
          log_text: logText || null
        })
      });
      
      // Get updated find count
      const cache = await apiRequest(`/rest/v1/caches?id=eq.${cacheId}&select=finds_count`);
      
      // Also store locally
      await storeLocalFind(cacheId);
      
      return { 
        success: true, 
        find: result[0],
        findNumber: cache[0]?.finds_count || 1,
        isFtc: result[0]?.is_ftc || false
      };
    } catch (error) {
      if (error.message.includes('duplicate') || error.message.includes('unique')) {
        return { success: false, error: 'You already found this cache!' };
      }
      // If API fails, fall back to local logging
      console.log('API log failed, storing locally:', error.message);
    }
  }
  
  // Not logged in or API failed - store locally and show success
  // This lets users still play and see progress in the extension
  await storeLocalFind(cacheId);
  
  // Get find count for this cache
  const localFinds = await getLocalFinds();
  const findNumber = localFinds.length;
  
  return { 
    success: true, 
    findNumber: findNumber,
    isFtc: false,
    localOnly: true,
    message: user ? 'Saved locally!' : 'Logged! Sign in on dashboard to save your progress.'
  };
}

// Store finds locally for users who aren't logged in
async function storeLocalFind(cacheId) {
  const { localFinds = [] } = await chrome.storage.local.get('localFinds');
  if (!localFinds.includes(cacheId)) {
    localFinds.push(cacheId);
    await chrome.storage.local.set({ localFinds });
  }
}

async function getLocalFinds() {
  const { localFinds = [] } = await chrome.storage.local.get('localFinds');
  return localFinds;
}

// Check if cache was found locally
async function isFoundLocally(cacheId) {
  const localFinds = await getLocalFinds();
  return localFinds.includes(cacheId);
}

async function dropCache({ url, name, clue, message, hint, difficulty }) {
  const user = await getUser();
  if (!user) {
    return { success: false, error: 'Not logged in. Please log in on the dashboard.' };
  }
  
  const normalizedUrl = normalizeUrl(url);
  const urlHash = await hashUrl(url);
  
  try {
    const result = await apiRequest('/rest/v1/caches', {
      method: 'POST',
      headers: {
        'Prefer': 'return=representation'
      },
      body: JSON.stringify({
        url: normalizedUrl,
        url_hash: urlHash,
        name,
        clue,
        message,
        hint: hint || null,
        difficulty: difficulty || 3,
        owner_id: user.id,
        owner_display: user.username || user.display_name || 'Anonymous'
      })
    });
    
    return { success: true, cache: result[0] };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function getUserStats() {
  const user = await getUser();
  if (!user) return null;
  
  try {
    const profile = await apiRequest(`/rest/v1/profiles?id=eq.${user.id}&select=*`);
    return profile[0] || null;
  } catch (error) {
    console.error('Error getting stats:', error);
    return null;
  }
}

// ============================================
// BADGE & ICON UPDATES
// ============================================

function updateBadge(tabId, status, cacheCount = 0) {
  const colors = {
    cold: '#888888',
    warm: '#F59E0B', 
    hot: '#C17F24',
    found: '#22c55e'
  };
  
  const text = {
    cold: '',
    warm: cacheCount > 1 ? String(cacheCount) : '~',
    hot: '!',
    found: '✓'
  };
  
  try {
    chrome.action.setBadgeBackgroundColor({ color: colors[status], tabId });
    chrome.action.setBadgeText({ text: text[status], tabId });
  } catch (e) {
    // Badge update failed, ignore
  }
}

// ============================================
// TAB LISTENERS
// ============================================

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
    const result = await checkUrlForCaches(tab.url);
    
    const badgeStatus = result.alreadyFound ? 'found' : result.status;
    updateBadge(tabId, badgeStatus, result.cacheCount);
    
    // Send to content script
    try {
      await chrome.tabs.sendMessage(tabId, { type: 'URL_STATUS', ...result });
    } catch (e) {
      // Content script not ready
    }
  }
});

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab.url && tab.url.startsWith('http')) {
      const result = await checkUrlForCaches(tab.url);
      const badgeStatus = result.alreadyFound ? 'found' : result.status;
      updateBadge(activeInfo.tabId, badgeStatus, result.cacheCount);
    }
  } catch (e) {
    // Tab might not exist
  }
});

// ============================================
// MESSAGE HANDLING
// ============================================

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handleMessage(msg, sender).then(sendResponse);
  return true;
});

// Listen for messages from dashboard (external)
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  const allowedOrigins = [CONFIG.DASHBOARD_URL, 'http://localhost:3000'];
  if (allowedOrigins.includes(sender.origin)) {
    handleMessage(msg, sender).then(sendResponse);
    return true;
  }
});

async function handleMessage(msg, sender) {
  switch (msg.type) {
    // === AUTH ===
    case 'AUTH_TOKEN': {
      await setAuth(msg.token, msg.user);
      return { success: true };
    }
    
    case 'AUTH_SYNC': {
      // Dashboard is telling us the user logged in
      // Store user info (we'll fetch fresh data from Supabase)
      if (msg.user) {
        await setAuth('session', msg.user);
        console.log('Auth synced from dashboard:', msg.user.username);
      }
      return { success: true };
    }
    
    case 'LOGOUT': {
      await clearAuth();
      return { success: true };
    }
    
    case 'GET_AUTH': {
      const token = await getAuthToken();
      const user = await getUser();
      return { token, user, isLoggedIn: !!token };
    }
    
    // === CACHE OPS ===
    case 'CHECK_URL': {
      return await checkUrlForCaches(msg.url);
    }
    
    case 'LOG_FIND': {
      return await logFind(msg.cacheId, msg.logText);
    }
    
    case 'DROP_CACHE': {
      return await dropCache({
        url: msg.url,
        name: msg.name,
        clue: msg.clue,
        message: msg.message,
        hint: msg.hint,
        difficulty: msg.difficulty
      });
    }
    
    case 'GET_STATS': {
      return await getUserStats();
    }
    
    // === NAVIGATION ===
    case 'OPEN_DASHBOARD': {
      chrome.tabs.create({ url: `${CONFIG.DASHBOARD_URL}${msg.path || ''}` });
      return { success: true };
    }
    
    case 'OPEN_URL': {
      chrome.tabs.create({ url: msg.url });
      return { success: true };
    }
    
    // === REFRESH ===
    case 'REFRESH': {
      // Re-check current tab
      if (sender.tab) {
        const result = await checkUrlForCaches(sender.tab.url);
        const badgeStatus = result.alreadyFound ? 'found' : result.status;
        updateBadge(sender.tab.id, badgeStatus, result.cacheCount);
        return result;
      }
      return { success: true };
    }
    
    default:
      return { error: 'Unknown message type: ' + msg.type };
  }
}

// ============================================
// STARTUP
// ============================================

chrome.runtime.onInstalled.addListener(() => {
  console.log('Webcrawl extension installed');
});
